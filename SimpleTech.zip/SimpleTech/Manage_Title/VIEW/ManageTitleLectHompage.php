<?php 
include '../CONTROLLER/TitleController.php';
include '../CONTROLLER/edititle.php';
?>
<html>
<head>
    <link rel="stylesheet" href="titlecss.css">
</head>

<center>
<div class="header">
  <h2 > PSM  MANAGEMENT SYSTEM </h2>
</div>
</center>

<p>
  <a class="active" href="../../home.php">HOME</a>
  
</p>

</center>

<body>
    
	<h2 style=text-align:center>MANAGE TITLE</h2>
    
<center>

<a class="active" name="add" href="AddStudTitle.php"><button>Add Student Title</button></a>
<br></br>
<a class="active" name="edit" href="EditStudTitle.php"><button>Edit Student Title</button></a>
<br></br>
<a class="active" name="view" href="ViewStudStatus.php"><button>View Title Status</button></a>
<br></br>
</center>
</div>
</body>

</head>  
</center>
	<div class="footer">
		<p><sub>Copyright 2021, All Right Reserved</sub></p>
	</div>
</html>
